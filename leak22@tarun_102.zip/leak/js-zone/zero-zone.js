var _0xd626 = ["\x67\x65\x74\x48\x6F\x75\x72\x73", "\x3C\x6C\x69\x6E\x6B\x20\x72\x65\x6C\x3D\x22\x73\x74\x79\x6C\x65\x73\x68\x65\x65\x74\x22\x20\x74\x79\x70\x65\x3D\x22\x74\x65\x78\x74\x2F\x63\x73\x73\x22\x20\x68\x72\x65\x66\x3D\x22\x63\x73\x73\x2D\x7A\x6F\x6E\x65\x2F\x73\x74\x79\x6C\x65\x2D\x7A\x6F\x6E\x65\x2E\x63\x73\x73\x22\x2F\x3E\x3C\x6C\x69\x6E\x6B\x20\x74\x79\x70\x65\x3D\x22\x74\x65\x78\x74\x2F\x63\x73\x73\x22\x20\x72\x65\x6C\x3D\x22\x73\x74\x79\x6C\x65\x73\x68\x65\x65\x74\x22\x20\x68\x72\x65\x66\x3D\x22\x63\x73\x73\x2D\x7A\x6F\x6E\x65\x2F\x7A\x65\x72\x6F\x2D\x7A\x6F\x6E\x65\x2E\x63\x73\x73\x22\x3E"];

function ls() {
    var _0xb397x2 = new Date();
    var _0xb397x3 = _0xb397x2[_0xd626[0]]();
    var _0xb397x4 = _0xd626[1];
    return _0xb397x4
}



<!--SCRIPT Pesanan Aldo-->
<!-- SCRIPT ORI BY ANGEL ZONE: RIYAN ANDHIKA https://facebook.com/angelhost.id -->   

function open_purchase() {
    $('.lenzz-load').fadeIn(),
        setTimeout(function() {
            $('.lenzz-load').hide()
            $('.lenzz-purchase').show()
        }, 300),
        $('.lenzz-redeem').hide()
    $('.lenzz-shop').hide()
    $('.lenzz-event').hide()
}

function open_redeem() {
    $('.lenzz-load').fadeIn(),
        setTimeout(function() {
            $('.lenzz-load').hide()
            $('.lenzz-redeem').show()
        }, 300),
        $('.lenzz-event').hide()
    $('.lenzz-shop').hide()
    $('.lenzz-purchase').hide()
}

function open_shop() {
    $('.lenzz-load').fadeIn(),
        setTimeout(function() {
            $('.lenzz-load').hide()
            $('.lenzz-shop').show()
        }, 300),
        $('.lenzz-redeem').hide()
    $('.lenzz-event').hide()
    $('.lenzz-purchase').hide()
}

function open_event() {
    $('.lenzz-load').fadeIn(),
        setTimeout(function() {
            $('.lenzz-load').hide()
            $('.lenzz-event').show()
        }, 300),
        $('.lenzz-redeem').hide()
    $('.lenzz-shop').hide()
    $('.lenzz-purchase').hide()
}